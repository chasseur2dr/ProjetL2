package Metier;


import java.util.Map;

public class Affectation {
	private PersonnelHospitalier personnel;
	private Creneau creneau;
	private String specialite;
	private Map<PersonnelHospitalier,Creneau> affecterA;
	
	public Affectation(PersonnelHospitalier personnel, Creneau creneau, String specialite,
			Map<PersonnelHospitalier, Creneau> affecterA) {
		this.personnel = personnel;
		this.creneau = creneau;
		this.specialite = specialite;
		this.affecterA = affecterA;
	}
	public PersonnelHospitalier getPersonnel() {
		return personnel;
	}
	public void setPersonnel(PersonnelHospitalier personnel) {
		this.personnel = personnel;
	}
	public Creneau getCreneau() {
		return creneau;
	}
	public void setCreneau(Creneau creneau) {
		this.creneau = creneau;
	}
	public String getSpecialite() {
		return specialite;
	}
	public void setSpecialite(String specialite) {
		this.specialite = specialite;
	}
	public Map<PersonnelHospitalier, Creneau> getAffecterA() {
		return affecterA;
	}

	public void setAffecterA(Map<PersonnelHospitalier, Creneau> affecterA) {
		this.affecterA = affecterA;
	}
	
}
