package Metier;

public class Heure {
	
	private int heure;
	private int min;
	
	
	public Heure(int heure, int min) {
	        this.heure = heure;
	        this.min = min;
	    }

	    public int getHeure() {
	        return heure;
	    }

	    public void setHeure(int heure) {
	        this.heure = heure;
	    }

	    public int getMin() {
	        return min;
	    }

	    public void setMin(int min) {
	        this.min = min;
	    }
	}