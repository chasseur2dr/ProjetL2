package Metier;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestPersonnel {

    private PersonnelHospitalier personnel;

    @BeforeEach
    void setUp() {
        personnel = new PersonnelHospitalier("Doe", "John", Date.valueOf("1990-01-01"), "Médecin", new ArrayList<>(), 40);
    }

    @Test
    void testAjouterSpecialite() {
        personnel.ajouterSpecialite("Cardiologie");
        personnel.ajouterSpecialite("Gastro-entérologie");

        ArrayList<String> specialites = personnel.getSpecialite();

        assertEquals(2, specialites.size());
        assertTrue(specialites.contains("Cardiologie"));
        assertTrue(specialites.contains("Gastro-entérologie"));
    }

    @Test
    void testSetAndGetId() {
        personnel.setId(1);
        assertEquals(1, personnel.getId());
    }

    @Test
    void testSetAndGetName() {
        personnel.setNom("Doe");
        personnel.setPrenom("Jane");

        assertEquals("Doe", personnel.getNom());
        assertEquals("Jane", personnel.getPrenom());
    }

    @Test
    void testSetAndGetDateNaissance() {
        Date dateNaissance = Date.valueOf("1990-01-01");
        personnel.setDateNaissance(dateNaissance);
        assertEquals(dateNaissance, personnel.getDateNaissance());
    }

    @Test
    void testSetAndGetFonction() {
        personnel.setFonction("Infirmier");
        assertEquals("Infirmier", personnel.getFonction());
    }

    @Test
    void testSetAndGetTempsTravailHebdomadaire() {
        personnel.setTempsTravailHebdomadaire(35);
        assertEquals(35, personnel.getTempsTravailHebdomadaire());
    }
}

