package Metier;

import java.util.ArrayList;


public class GestionnaireEmploiDuTemps {
	private ContraintesLegales contraintesLegales;
	private ArrayList<PersonnelHospitalier> listePersonnels;
	private ArrayList<String> listeSpecialites;
	private ArrayList<String> listeFonctions;
	private ArrayList<Creneau> listeCreneaux;
	private ArrayList<Affectation> listeAffectation;
	
	public GestionnaireEmploiDuTemps(ContraintesLegales contraintesLegales, ArrayList<PersonnelHospitalier> listePersonnels,
			ArrayList<String> listeSpecialites, ArrayList<String> listeFonction, ArrayList<Creneau> listeCreneau,
			ArrayList<Affectation> listeAffectation) {
		this.contraintesLegales = contraintesLegales;
		this.listePersonnels = listePersonnels;
		this.listeSpecialites = listeSpecialites;
		this.listeFonctions = listeFonctions;
		this.listeCreneaux = listeCreneaux;
		this.listeAffectation = listeAffectation;
	}
	public ContraintesLegales getContraintesLegales() {
		return contraintesLegales;
	}
	public void setContraintesLegales(ContraintesLegales contraintesLegales) {
		this.contraintesLegales = contraintesLegales;
	}
	public ArrayList<PersonnelHospitalier> getListePersonnels() {
		return listePersonnels;
	}
	public void setListePersonnels(ArrayList<PersonnelHospitalier> listePersonnels) {
		this.listePersonnels = listePersonnels;
	}
	public ArrayList<String> getListeSpecialites() {
		return listeSpecialites;
	}
	public void setListeSpecialites(ArrayList<String> listeSpecialites) {
		this.listeSpecialites = listeSpecialites;
	}
	public ArrayList<String> getListeFonctions() {
		return listeFonctions;
	}
	public void setListeFonctions(ArrayList<String> listeFonctions) {
		this.listeFonctions = listeFonctions;
	}
	public ArrayList<Creneau> getListeCreneaux() {
		return listeCreneaux;
	}
	public void setListeCreneaux(ArrayList<Creneau> listeCreneaux) {
		this.listeCreneaux = listeCreneaux;
	}
	public ArrayList<Affectation> getListeAffectation() {
		return listeAffectation;
	}
	public void setListeAffectation(ArrayList<Affectation> listeAffectation) {
		this.listeAffectation = listeAffectation;
	}
	
	/**
	 * Permet d'ajouter un nouveau Personnel dans la liste
	 * @param nouveauPersonnel
	 */
	
	public void ajouterPersonnel(PersonnelHospitalier nouveauPersonnel) {
        if (listePersonnels == null) {
            listePersonnels = new ArrayList<>(); // Initialiser la liste si elle est null
        }
        listePersonnels.add(nouveauPersonnel);
    }
	
	/**
	 * Permet d'ajouter un nouvelle Specialite dans la liste
	 * @param nouveSpecialites
	 */
	
	public void ajouterSpecialites(String nouvelleSpecialite) {
        if (listeSpecialites == null) {
            listeSpecialites = new ArrayList<>(); // Initialiser la liste si elle est null
        }
        listeSpecialites.add(nouvelleSpecialite);
	}
	
	/**
	 * Permet d'ajouter un nouvelle Fonction dans la liste
	 * @param nouvelleFonctionl
	 */
	
	public void ajouterFonction(String nouvelleFonction) {
        if (listeFonctions == null) {
            listeFonctions = new ArrayList<>(); // Initialiser la liste si elle est null
        }
        listeFonctions.add(nouvelleFonction);
	}
	
	/**
	 * Permet d'ajouter un nouveau Creneau dans la liste
	 * @param nouveauCreneau
	 */
	
	public void ajouterCreneaux(Creneau nouveauCreneaux) {
        if (listeCreneaux == null) {
            listeCreneaux = new ArrayList<>(); // Initialiser la liste si elle est null
        }
        listeCreneaux.add(nouveauCreneaux);
	}
	
}
