package Metier;

public class ContraintesLegales {
	
	public boolean verifContrainte(PersonnelHospitalier p) {
		boolean verification = true;
		
		/* contrainte de temps de travail maximum */
		if(p.getTempsTravailHebdomadaire() >50) {
			verification = false;
		}
		return verification;
	}

}
