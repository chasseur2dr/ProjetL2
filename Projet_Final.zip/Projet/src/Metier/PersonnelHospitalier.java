package Metier;

import java.sql.Date;
import java.util.ArrayList;

public class PersonnelHospitalier {
	
	private int id;
	private String nom;
	private String prenom;
	private Date dateNaissance;
	private String fonction;
	private ArrayList<String> specialite;
	private int tempsTravailHebdomadaire;
	
	public PersonnelHospitalier(int id,String nom, String prenom, Date dateNaissance, String fonction, ArrayList<String> specialite, int tempsTravailHebdomadaire) {
		this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.fonction = fonction;
        this.specialite = specialite;
        this.tempsTravailHebdomadaire = tempsTravailHebdomadaire;
	}
	
	public PersonnelHospitalier(String nom, String prenom, Date dateNaissance, String fonction, ArrayList<String> specialite) {
		this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.fonction = fonction;
        this.specialite = specialite;
        this.tempsTravailHebdomadaire = 0;
		
	}
	
	/**
	 * Permet d'ajouter une nouvelle specialiter dans la liste
	 * @param nouvelleSpecialite
	 */
	
	public void ajouterSpecialite(String nouvelleSpecialite) {
        if (specialite == null) {
            specialite = new ArrayList<>(); // Initialiser la liste si elle est null
        }
        specialite.add(nouvelleSpecialite);
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

	public String getFonction() {
		return fonction;
	}

	public void setFonction(String fonction) {
		this.fonction = fonction;
	}

	public ArrayList<String> getSpecialite() {
		return specialite;
	}

	public void setSpecialite(ArrayList<String> specialite) {
		this.specialite = specialite;
	}

	public int getTempsTravailHebdomadaire() {
		return tempsTravailHebdomadaire;
	}

	public void setTempsTravailHebdomadaire(int tempsTravailHebdomadaire) {
		this.tempsTravailHebdomadaire = tempsTravailHebdomadaire;
	}
	

}