package Metier;

public class Fonction {
	private static int dernierId = 0;

    private int idFonction;
    private String nomFonction;

    public Fonction(String nomFonction) {
        this.idFonction = ++dernierId;
        this.nomFonction = nomFonction;
    }

    public int getIdFonction() {
        return idFonction;
    }

    public String getNomFonction() {
        return nomFonction;
    }

    public void setNomFonction(String nomFonction) {
        this.nomFonction = nomFonction;
    }
}