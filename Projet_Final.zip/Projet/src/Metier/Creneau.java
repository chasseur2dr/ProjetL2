package Metier;

import java.sql.Date;
import java.util.Map;

public class Creneau {
	private static int dernierId = 0;
	private int id;
	private Date date;
	private PlageHoraire plageHoraire;
	private  Map<String, Integer> besoinPersonnel;
	
	public Creneau(Date date, PlageHoraire plageHoraire, Map<String, Integer> besoinPersonnel) {
		this.id = ++dernierId;
        this.date = date;
        this.plageHoraire = plageHoraire;
        this.besoinPersonnel = besoinPersonnel;
    }

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public PlageHoraire getPlageHoraire() {
		return plageHoraire;
	}

	public void setPlageHoraire(PlageHoraire plageHoraire) {
		this.plageHoraire = plageHoraire;
	}

	public Map<String, Integer> getBesoinPersonnel() {
		return besoinPersonnel;
	}

	public void setBesoinPersonnel(Map<String, Integer> besoinPersonnel) {
		this.besoinPersonnel = besoinPersonnel;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

}