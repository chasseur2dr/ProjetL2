package Metier;


public class PlageHoraire {
	
	private Heure heureDebut;
	private Heure heureFin;
	
	public PlageHoraire() {
		this.heureDebut = new Heure(0, 0);
		this.heureFin = new Heure(0, 0);
		
	}
	
	public PlageHoraire(Heure heureDebut, Heure heureFin) {
		this.heureDebut = heureDebut;
		this.heureFin = heureFin;
	}

	public Heure getHeureDebut() {
		return heureDebut;
	}

	public void setHeureDebut(Heure heureDebut) {
		this.heureDebut = heureDebut;
	}

	public Heure getHeureFin() {
		return heureFin;
	}

	public void setHeureFin(Heure heureFin) {
		this.heureFin = heureFin;
	}

	
}
