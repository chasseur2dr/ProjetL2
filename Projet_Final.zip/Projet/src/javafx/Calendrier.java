package javafx;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Metier.Creneau;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


public class Calendrier extends Application{

	public static void main(String[] args) {
		Application.launch(args);
	}	

	@Override
	public void start(Stage primaryStage) {
		
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.CENTER);
		gridPane.setHgap(2);
		gridPane.setVgap(2);
		
		ListView<Creneau> listview = new ListView<Creneau>();
		gridPane.add(listview, 1, 1);
		
		Button ajtCreneau = new Button("Ajouter Creneau");
		gridPane.add(ajtCreneau, 0, 2);
		ajtCreneau.setOnAction(e -> {
		    ajoutCreneau game = new ajoutCreneau();
		    primaryStage.getScene().setRoot(game.getGridPane());
		});
		
		final DatePicker datePicker = new DatePicker(); 
        datePicker.setValue(LocalDate.now()); 
        gridPane.add(datePicker, 1, 0);
        
        final StackPane root = new StackPane(); 
        root.getChildren().add(datePicker);
        gridPane.add(root, 0, 0);
		
		Scene scene = new Scene(gridPane, 1000, 800);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
 }