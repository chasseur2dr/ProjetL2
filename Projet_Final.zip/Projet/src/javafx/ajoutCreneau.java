package javafx;


import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class ajoutCreneau {

	    private final GridPane gridPane ; 

	    public ajoutCreneau() {

	        gridPane  = new GridPane();
	        
	        DatePicker date = new DatePicker();
	        gridPane.add(date, 0, 0);
	        
	        TextField plageHoraire = new TextField("");
	        gridPane.add(plageHoraire, 0, 1);

	        Button back = new Button("Retour");
	        gridPane.add(back, 0, 5);
	        back.setOnAction(e -> {
			    Calendrier game = new Calendrier();
			    primaryStage.getScene().setRoot(game));
			});
	    }

	    public Pane getGridPane() {
	        return gridPane ;
	    }

}
