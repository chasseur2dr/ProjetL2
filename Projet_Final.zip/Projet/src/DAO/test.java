package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import com.mysql.cj.jdbc.MysqlDataSource;

import Metier.Creneau;
import Metier.Fonction;
import Metier.Heure;
import Metier.PersonnelHospitalier;
import Metier.PlageHoraire;

public class test {

    public static void main(String[] args) {
        String databaseName = "hospitalier";
        // Paramètres de connexion : url, login, mdp
        // Port mysql avec USBWebserver:3307, xampp: 3306
        String url = "jdbc:mysql://localhost:3307/" + databaseName + "?serverTimezone=UTC";
        String login = "root";
        String password = "usbw";

        Connection cn = null;

        MysqlDataSource mysqlDS = new MysqlDataSource();
        mysqlDS.setURL(url);
        mysqlDS.setUser(login);
        mysqlDS.setPassword(password);

        try {
            cn = mysqlDS.getConnection();
        } catch (SQLException e1) {
            System.err.println("Erreur de parcours de connexion");
            e1.printStackTrace();
        }

        /* // Création d'une plage horaire
        PlageHoraire plage = new PlageHoraire(new Heure(0, 0), new Heure(1, 0));

        // Création d'un créneau
        Creneau creneau = new Creneau(new Date(5, 7, 25), plage, null);

        // Création d'une instance de CreneauDAO
        CreneauDAO creneauDAO = new CreneauDAO();

        // Test de la méthode create
        creneauDAO.create(creneau);
        System.out.println("Créneau créé avec succès.");

        plage = new PlageHoraire(new Heure(0, 0), new Heure(2, 0));
        creneau.setPlageHoraire(plage);

        creneauDAO.update(creneau);
        System.out.println("Créneau mis à jour avec succès.");

        creneauDAO.delete(creneau);
        System.out.println("Créneau supprimé avec succès.");
        
        Fonction f = new Fonction("test1");
        FonctionDAO fDAO = new FonctionDAO();
        fDAO.create(f);
        fDAO.update(f);
        fDAO.delete(f);
        System.out.println("Créneau supprimé avec succès.");*/
        PersonnelHospitalier perso = new PersonnelHospitalier(1, "nomPersonne", "prenomPersonne", new Date(3, 11, 1975), null, null, 0);
        PersonnelDAO PDAO = new PersonnelDAO();
        PDAO.create(perso);
        PDAO.update(perso);
        PDAO.delete(perso);
        System.out.println("Créneau supprimé avec succès.");
        
        
        
        
        
    }
}