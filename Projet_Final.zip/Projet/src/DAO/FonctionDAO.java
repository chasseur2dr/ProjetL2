package DAO;

import java.sql.SQLException;

import Metier.Fonction;

public class FonctionDAO extends DAO<Fonction>{
	@Override
	public Fonction create(Fonction obj) {
		String requete = "INSERT INTO fonction (id_Fonction, nom_Fonction) ";
		requete += "VALUES('" + obj.getIdFonction() + "' ,'" + obj.getNomFonction() + "')";
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@Override
	public Fonction update(Fonction obj) {
		String requete = "UPDATE fonction SET nom_Fonction = '" + obj.getNomFonction() + "' ";
		requete += "WHERE id_Fonction = '" + obj.getIdFonction() + "'";
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj;
	}
	@Override
	public void delete(Fonction obj) {
		String requete = "DELETE FROM fonction WHERE id_Fonction = '" + obj.getIdFonction() + "'";
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
