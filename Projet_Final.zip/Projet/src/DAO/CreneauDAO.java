package DAO;

import java.sql.SQLException;

import Metier.Creneau;

public class CreneauDAO extends DAO<Creneau> {

	@Override
	public Creneau create(Creneau obj) {
		String requete = "INSERT INTO créneau (id_creneau, date_creneau, plage_horaire_debut, plage_horaire_fin, besoin) ";
		requete = requete + "VALUES(" + obj.getId() + ", '" + obj.getDate() + "', '" + obj.getPlageHoraire().getHeureDebut().getHeure() + "', '" + obj.getPlageHoraire().getHeureFin().getHeure() + "', '" + obj.getBesoinPersonnel() + "')";
		try {
		    stmt.executeUpdate(requete);
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return obj;
		}

	@Override
	public Creneau update(Creneau obj) {
		// TODO Auto-generated method stub
		String requete = "UPDATE créneau SET date_creneau ='" + obj.getDate() + "', ";
		requete += "plage_horaire_debut= '" + obj.getPlageHoraire().getHeureDebut().getHeure() + "', ";
		requete += "plage_horaire_fin= '" + obj.getPlageHoraire().getHeureFin().getHeure() + "', ";
		requete += "besoin= '" + obj.getBesoinPersonnel() + "' ";
		requete += "WHERE id_creneau = " + obj.getId();
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj;

		}

	@Override
	public void delete(Creneau obj) {
		 String requete = "DELETE FROM créneau ";
		    requete += "WHERE id_creneau = '" + obj.getId() + "'";

		    try {
		        stmt.executeUpdate(requete);
		        System.out.println("Suppression réussie !");
		    } catch (SQLException e) {
		        System.err.println("Erreur lors de la suppression : " + e.getMessage());
		        e.printStackTrace();
		    }
		}
		

}
