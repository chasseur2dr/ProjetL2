package DAO;

import java.sql.SQLException;

import Metier.PersonnelHospitalier;

public class PersonnelDAO extends DAO<PersonnelHospitalier> {

	@Override
	public PersonnelHospitalier create(PersonnelHospitalier obj) {
		// TODO Auto-generated method stub
		 String requete = "INSERT INTO personnel (id, nom, prenom, date_naissance, temps_travail) ";
		    requete += "VALUES('" + obj.getId() + "', '" + obj.getNom() + "', '" + obj.getPrenom() + "', '" + obj.getDateNaissance() + "', " + obj.getTempsTravailHebdomadaire() + ")";
		try {
			//stmt.executeUpdate(requete,Statement.RETURN_GENERATED_KEYS);
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}

	@Override
	public PersonnelHospitalier update(PersonnelHospitalier obj) {
		// TODO Auto-generated method stub
		 String requete = "UPDATE personnel SET nom = '" + obj.getNom() + "', ";
		    requete += "prenom = '" + obj.getPrenom() + "', ";
		    requete += "date_naissance = '" + obj.getDateNaissance() + "', ";
		    requete += "temps_travail = '" + obj.getTempsTravailHebdomadaire() + "' ";
		    requete += "WHERE id = " + obj.getId();
		    
		    try {
		        stmt.executeUpdate(requete);
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return obj;
		}

	@Override
	public void delete(PersonnelHospitalier obj) {
		// TODO Auto-generated method stub
		    String requete = "DELETE FROM Personnel";
		    requete += " WHERE id = '" + obj.getId() + "' ";

		    try {
		        stmt.executeUpdate(requete);
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

}